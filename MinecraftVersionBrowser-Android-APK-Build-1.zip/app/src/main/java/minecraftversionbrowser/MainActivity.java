package minecraftversionbrowser;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String MANIFEST =
        "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ArrayList<Version> versions = new ArrayList<>();
    private final ArrayList<Version> shown = new ArrayList<>();
    private LinearLayout list;
    private EditText search;
    private TextView status;
    private Spinner typeFilter;
    private ProgressBar progress;

    static class Version {
        String id, type, url, releaseTime, sha1;
        Version(JSONObject o) throws Exception {
            id = o.optString("id", "");
            type = o.optString("type", "unknown");
            url = o.optString("url", "");
            releaseTime = o.optString("releaseTime", "");
            sha1 = o.optString("sha1", "");
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(25, 38, 28));
        getWindow().setNavigationBarColor(Color.rgb(25, 38, 28));
        buildUi();
        loadVersions();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(8));
        root.setBackgroundColor(Color.rgb(242, 245, 240));
        setContentView(root);

        TextView title = text("Minecraft Version Browser", 24, Color.rgb(31, 57, 36));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);
        TextView subtitle = text("Browse official Minecraft: Java Edition versions", 13, Color.DKGRAY);
        LinearLayout.LayoutParams subP = new LinearLayout.LayoutParams(-1, -2);
        subP.bottomMargin = dp(14); root.addView(subtitle, subP);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search versions (e.g. 1.20.4)");
        search.setPadding(dp(12), 0, dp(12), 0);
        search.setBackground(bg(Color.WHITE, 12));
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(48)));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));
        typeFilter = new Spinner(this);
        String[] options = {"All versions", "Release", "Snapshot", "Old beta", "Old alpha"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, options);
        typeFilter.setAdapter(adapter);
        row.addView(typeFilter, new LinearLayout.LayoutParams(0, dp(46), 1));
        Button refresh = new Button(this); refresh.setText("Refresh");
        row.addView(refresh);
        root.addView(row);

        status = text("Connecting to Mojang…", 13, Color.DKGRAY);
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(28)));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(4)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(8), 0, dp(12));
        scroll.addView(list);
        LinearLayout.LayoutParams scrollP = new LinearLayout.LayoutParams(-1, 0, 1);
        scrollP.topMargin = dp(4); root.addView(scroll, scrollP);

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int before, int count) { render(); }
            public void afterTextChanged(Editable e) {}
        });
        typeFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { render(); }
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });
        refresh.setOnClickListener(v -> loadVersions());
    }

    private void loadVersions() {
        progress.setVisibility(View.VISIBLE);
        status.setText("Loading official version manifest…");
        executor.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection)new URL(MANIFEST).openConnection();
                c.setConnectTimeout(12000); c.setReadTimeout(15000);
                c.setRequestProperty("User-Agent", "MinecraftVersionBrowser-Android/2.0.1");
                StringBuilder body = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                    String line; while ((line = r.readLine()) != null) body.append(line);
                }
                JSONObject json = new JSONObject(body.toString());
                JSONArray arr = json.getJSONArray("versions");
                ArrayList<Version> fresh = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) fresh.add(new Version(arr.getJSONObject(i)));
                runOnUiThread(() -> {
                    versions.clear(); versions.addAll(fresh);
                    progress.setVisibility(View.GONE);
                    status.setText(versions.size() + " official Java versions • Updated just now");
                    render();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    status.setText("Could not load versions. Check your internet and tap Refresh.");
                    Toast.makeText(this, "Load failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            } finally { if (c != null) c.disconnect(); }
        });
    }

    private void render() {
        if (list == null) return;
        list.removeAllViews(); shown.clear();
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int filter = typeFilter == null ? 0 : typeFilter.getSelectedItemPosition();
        String[] kinds = {"", "release", "snapshot", "old_beta", "old_alpha"};
        for (Version v : versions) {
            if (!v.id.toLowerCase(Locale.ROOT).contains(q)) continue;
            if (filter > 0 && !v.type.equals(kinds[filter])) continue;
            shown.add(v);
        }
        if (shown.isEmpty()) {
            TextView empty = text(versions.isEmpty() ? "No data loaded yet." : "No matching versions.", 15, Color.DKGRAY);
            empty.setPadding(dp(12), dp(18), dp(12), dp(18)); list.addView(empty); return;
        }
        for (Version v : shown) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            card.setBackground(bg(Color.WHITE, 12));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.bottomMargin = dp(8); list.addView(card, cp);
            TextView id = text(v.id, 18, Color.rgb(35, 69, 43));
            id.setTypeface(Typeface.DEFAULT, Typeface.BOLD); card.addView(id);
            TextView meta = text(v.type.toUpperCase(Locale.ROOT) + "  •  " + formatDate(v.releaseTime), 12, Color.DKGRAY);
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
            mp.topMargin = dp(4); card.addView(meta, mp);
            card.setOnClickListener(view -> showDetails(v));
        }
        status.setText(versions.size() + " versions available • Showing " + shown.size());
    }

    private String formatDate(String value) {
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX", Locale.US).parse(value);
            return new SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(d);
        } catch (Exception e) { return value.length() >= 10 ? value.substring(0, 10) : value; }
    }

    private void showDetails(Version v) {
        String details = "Version: " + v.id + "\nType: " + v.type + "\nRelease time: " + v.releaseTime
            + "\n\nVersion JSON URL:\n" + v.url + "\n\nSHA-1:\n" + v.sha1;
        new android.app.AlertDialog.Builder(this).setTitle(v.id).setMessage(details)
            .setPositiveButton("Open version JSON", (d, w) -> {
                try { startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(v.url))); }
                catch (Exception ex) { Toast.makeText(this, "No browser available", Toast.LENGTH_SHORT).show(); }
            }).setNegativeButton("Close", null).show();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }
}
