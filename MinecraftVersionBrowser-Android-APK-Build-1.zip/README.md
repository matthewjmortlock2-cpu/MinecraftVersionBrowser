# Minecraft Version Browser — Android project

This Android version provides a native app for browsing the official Minecraft Java Edition
version manifest from Mojang. Features include live loading, version-ID search, type filters,
refresh, and a details dialog with the official version metadata URL and SHA-1.

## Build an installable APK using GitHub Actions (phone-friendly; no Android Studio needed)

This project includes `.github/workflows/build-apk.yml`, which builds a debug APK in GitHub's
cloud build environment.

1. In your phone browser, sign in or create an account at https://github.com.
2. Create a **new public or private repository** named `MinecraftVersionBrowser`.
3. Upload the contents of this ZIP into the repository (upload the files/folders inside this ZIP,
   not the ZIP file itself). Ensure `.github/workflows/build-apk.yml` is included.
4. Commit the upload to the `main` branch.
5. Open the repository's **Actions** tab and select **Build Android APK**.
6. Wait for the run to finish with a green check mark.
7. Open the completed run, scroll to **Artifacts**, and download
   `MinecraftVersionBrowser-debug-apk`.
8. Extract the downloaded artifact ZIP to get `app-debug.apk`, then tap the APK on your Mobicel.
   If Android blocks the installation, allow “Install unknown apps” for the app you used to open it,
   and retry. Only install APKs you trust.

## Build with Android Studio

Open this project in Android Studio, allow Gradle sync, then select **Build → Build APK(s)**.
The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations

- This is an Android implementation of the Java Edition version browser, not a byte-for-byte port
  of every feature from the original desktop JAR.
- Bedrock is not listed in Mojang's Java version manifest; Bedrock is linked to the official updates
  page in the original project if that UI is later added.
- Original desktop `.class` files are retained under `app/src/main/assets/legacy-classes/` for
  reference only. Android does not execute those JVM class files directly.
- The debug APK produced by this workflow is unsigned with a release key and is suitable for
  testing/side-loading, not Play Store publishing.
